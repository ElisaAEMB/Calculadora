package pages;

public class CalculatorPage extends BasePage{
    private String searchButtonEqual = "//button[@name='equal']";
    private String searchButtonOperation = "//button[@id='add']";
    private String searchNumber="//button[text()='%s']";
    private String firstResult = "";
    public CalculatorPage() {
        super(driver);
    }

    public void navigateToCalculator() {
        navigateTo("http://localhost/");
    }

    public void enterNumberToCalculate(String numberOne, String numberTwo, String textElementToSearch){
        clickElement(String.format(searchNumber,numberOne));
        clickElement(String.format(searchButtonOperation));
        clickElement(String.format(searchNumber,numberTwo));
    }
    public void clickOnButton(){
        clickElement(searchButtonEqual);
    }

    public String validateResult(String result){
        System.out.println(firstResult);
        return textFromElement(firstResult);
    }
}
