package steps;

import io.cucumber.java.en.*;
import pages.CalculatorPage;


public class CalculadoraSteps {
    CalculatorPage calculator = new CalculatorPage();

    @Given("^the user has two number$")
    public void navigateToCalculator(){
        calculator.navigateToCalculator();
    }

    @When("the user sends the numbers {word} and {word} the operation {word}")
    public void enterNumbers(String numberOne, String numberTwo, String operation){
        calculator.enterNumberToCalculate(numberOne,numberTwo,operation);
    }

    @Then("the user should get the result the number {word}")
    public void validateResults(String result){
        calculator.clickOnButton();
        calculator.validateResult(result);

    }
}
